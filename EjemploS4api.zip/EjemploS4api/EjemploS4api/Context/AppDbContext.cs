﻿using EjemploS4api.Models;
using Microsoft.EntityFrameworkCore;

namespace EjemploS4api.Context
{
    public class AppDbContext: DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }
    }

    public DbSet<Usuario> usuarios { get; set; }
}
